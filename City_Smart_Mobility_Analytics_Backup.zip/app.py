
import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

st.set_page_config(
    page_title="City Smart Mobility Analytics",
    page_icon="🚌",
    layout="wide"
)

BASE = Path(__file__).parent
OUTPUT = BASE / "outputs"

st.title("City Smart Mobility Analytics Platform")
st.caption("Road accident trends and public transport service analysis")

@st.cache_data
def load_data(filename):
    path = OUTPUT / filename
    if path.exists():
        return pd.read_csv(path)
    return pd.DataFrame()

accidents = load_data("annual_accident_risk_analysis.csv")
hourly = load_data("hourly_bus_activity.csv")
routes = load_data("route_activity.csv")

tab1, tab2, tab3 = st.tabs([
    "Accident Analysis",
    "Bus Service Activity",
    "Route Performance"
])

with tab1:
    st.header("Road Accident Analysis")

    if not accidents.empty:
        col1, col2, col3 = st.columns(3)

        col1.metric("Recorded Accidents",
                    f"{accidents['Accidents'].sum():,.0f}")

        col2.metric("Years Analysed", len(accidents))

        highest = accidents.loc[accidents["Accidents"].idxmax()]
        col3.metric("Highest Accident Year", str(int(highest["Year"])))

        fig = px.bar(
            accidents,
            x="Year",
            y="Accidents",
            title="Annual Recorded Accidents"
        )
        st.plotly_chart(fig, use_container_width=True)

        if "Risk_Score" in accidents.columns:
            fig2 = px.bar(
                accidents,
                x="Year",
                y="Risk_Score",
                color="Risk_Level",
                title="Relative Accident Volume Index"
            )
            st.plotly_chart(fig2, use_container_width=True)

        st.dataframe(accidents, use_container_width=True)
        st.download_button(
            "Download accident analysis",
            accidents.to_csv(index=False),
            "accident_analysis.csv",
            "text/csv"
        )
    else:
        st.warning("Accident analysis CSV is not available.")

with tab2:
    st.header("Scheduled Bus Activity")

    if not hourly.empty:
        selected_hours = st.multiselect(
            "Select operating hours",
            sorted(hourly["Hour"].dropna().unique()),
            default=sorted(hourly["Hour"].dropna().unique())
        )

        filtered = hourly[hourly["Hour"].isin(selected_hours)]

        fig = px.bar(
            filtered,
            x="Hour",
            y="Scheduled_Departures",
            title="Scheduled Departures by Hour"
        )
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(filtered, use_container_width=True)
        st.download_button(
            "Download hourly activity",
            filtered.to_csv(index=False),
            "hourly_bus_activity.csv",
            "text/csv"
        )
    else:
        st.warning("Hourly bus activity CSV is not available.")

with tab3:
    st.header("Bus Route Performance")

    if not routes.empty:
        top_n = st.slider(
            "Number of routes to display",
            min_value=5,
            max_value=min(30, len(routes)),
            value=min(15, len(routes))
        )

        top_routes = routes.nlargest(top_n, "Scheduled_Trips")

        fig = px.bar(
            top_routes,
            x="route_id",
            y="Scheduled_Trips",
            title=f"Top {top_n} Routes by Scheduled Trips"
        )
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(top_routes, use_container_width=True)
        st.download_button(
            "Download route analysis",
            top_routes.to_csv(index=False),
            "route_activity.csv",
            "text/csv"
        )
    else:
        st.warning("Route activity CSV is not available.")

st.divider()
st.caption(
    "Data scope: Historical accident statistics and Hyderabad GTFS "
    "scheduled services are separate datasets. Scheduled trips do not "
    "represent passenger counts or road congestion."
)
